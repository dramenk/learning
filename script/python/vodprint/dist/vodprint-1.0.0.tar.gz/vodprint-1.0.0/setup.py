from distutils.core import setup

setup(
		name = 'vodprint',
		version = '1.0.0',
		py_modules = ['vodprint']
	 )
